# pasta-bake
A POC using AWS Lambda, Serverless and DynamoDB
