const config = {
	host: 'search-pasta-bake-56moinu2ahu3t7y5h7jqnaneti.ap-southeast-2.es.amazonaws.com',
	index: 'researchhub',
	type: {
		catalogue: 'catalogue',
		nugget: 'nugget',
	}
};

module.exports = config;
